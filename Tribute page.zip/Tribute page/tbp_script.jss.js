var typed = new Typed(".typing",{
    strings: ["An Inspiration", "Helper", "Feeds People", "Theosophist","Nobel price for peace", "Poor People's God", "Reformer",],
    typeSpeed:100,
    backSpeed:80,
    loop:true
});